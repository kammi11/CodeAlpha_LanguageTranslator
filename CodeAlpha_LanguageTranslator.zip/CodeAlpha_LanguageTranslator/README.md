# CodeAlpha_LanguageTranslator

A simple web-based language translation tool built with Streamlit. Translate text between multiple languages instantly, no API key required.

## Internship
This project was built as part of the **CodeAlpha** internship program.

## Features
- Enter any text to translate
- Select source and target language from a dropdown
- One-click translation
- Instant results displayed in the app

## Tech Stack
- Python
- Streamlit
- [deep-translator](https://github.com/nidhaloff/deep-translator) (Google Translate backend, free, no API key)

## Setup

```bash
git clone https://github.com/<your-username>/CodeAlpha_LanguageTranslator.git
cd CodeAlpha_LanguageTranslator
pip install -r requirements.txt
streamlit run app.py
```

## Demo
_Add a screenshot or GIF of the app here._

## Author
Qaim Ali
